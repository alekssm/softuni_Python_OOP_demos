from project.fruit import Fruit

fruit = Fruit("Banana", "2022.11.17")
print(fruit.name)
print(fruit.expiration_date)